import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  gifs = new BehaviorSubject<any>([]);

  constructor(private http: HttpClient) { }

  //get trandings
  getTrendingGifs() {
    return this.http.get('https://api.giphy.com/v1/gifs/trending?api_key=EseRBMi91MekeILtiFGLt4s5FknoQ3fS&limit=50&rating=g')
    .subscribe((response: any) => {
      this.gifs.next(response.data);
    });
  }

  //search gif
  searchGifs(_gifName:string){
    return this.http.get('https://api.giphy.com/v1/gifs/search?api_key=EseRBMi91MekeILtiFGLt4s5FknoQ3fS&q=happy&limit=50&offset=0&rating=g&lang=en')
      .subscribe((response: any) => {
        console.log('Search Data',response);
        this.gifs.next(response.data);
    });

}

getGifs(){
  return this.gifs.asObservable();
}
}
function subscribe(arg0: (response: any) => void) {
  throw new Error('Function not implemented.');
}

